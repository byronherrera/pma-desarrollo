UPDATE `amc_operativos` SET `id_estado` = '4' WHERE `amc_operativos`.`id` =754;

